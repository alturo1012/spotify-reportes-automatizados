"""Pruebas de src/chart_semanal.py — usan una base SQLite temporal (nunca
tocan data/history/universal_data.db de verdad).

Corre con: pytest tests/test_chart_semanal.py -v
"""
import openpyxl
import pandas as pd
import pytest

from src import chart_semanal, config, history


@pytest.fixture(autouse=True)
def db_temporal(tmp_path, monkeypatch):
    """Redirige history.DB_PATH a un archivo temporal por cada test, para no
    tocar nunca la base real del proyecto."""
    monkeypatch.setattr(history, "DB_PATH", tmp_path / "test_universal_data.db")


def _csv_vacio(tmp_path, nombre, columnas):
    path = tmp_path / nombre
    pd.DataFrame(columns=columnas).to_csv(path, index=False)
    return path


def test_construir_resumen_total_pivotea_columnas_pais_banda(tmp_path):
    chart_csv = tmp_path / "seed_chart.csv"
    pd.DataFrame([
        {"anio": 2026, "semana": 1, "mes": "ENERO", "country_code": "CO", "banda": 10, "conteo_universal": 1},
        {"anio": 2026, "semana": 1, "mes": "ENERO", "country_code": "CO", "banda": 30, "conteo_universal": 5},
        {"anio": 2026, "semana": 1, "mes": "ENERO", "country_code": "PE", "banda": 10, "conteo_universal": 2},
    ]).to_csv(chart_csv, index=False)
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    resumen = chart_semanal.construir_resumen_total()

    assert list(resumen.columns[:3]) == ["anio", "semana", "mes"]
    assert "CO_top10" in resumen.columns and "PE_top10" in resumen.columns
    fila = resumen.iloc[0]
    assert fila["CO_top10"] == 1
    assert fila["CO_top30"] == 5
    assert fila["PE_top10"] == 2


def test_construir_resumen_total_vacio_no_falla(tmp_path):
    resumen = chart_semanal.construir_resumen_total()
    assert resumen.empty


def test_append_semana_chart_guarda_mes_en_espanol_no_en_ingles(tmp_path):
    # Regresión del bug real que encontramos: fecha.strftime("%B") depende
    # del locale del sistema y puede devolver "JUNE" en vez de "JUNIO",
    # rompiendo la continuidad con el histórico sembrado (que siempre está
    # en español). Verificado contra Reporte_Chart_Top Semanal Spotify Latam
    # a Sem 24 de 2026.xlsm, donde todas las filas usan mes en español.
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO"],
        "label_group": ["Universal"],
        "position": [1],
        "stream_count": [1_000_000],
        "chart_date": pd.to_datetime(["2026-06-18"]),
    })
    history.append_semana_chart(df_semana)

    chart_df = history.cargar_chart_band_weekly()
    assert chart_df["mes"].iloc[0] == "JUNIO"


def test_construir_detalle_tracks_arma_una_fila_por_posicion_con_una_columna_por_pais(tmp_path):
    # Formato ancho (Ajuste 4): antes era una tabla larga (una fila por
    # país+posición); ahora una fila por posición con un país por columna,
    # para que se vea como la plantilla original.
    df_semana = pd.DataFrame({
        "country_code": ["PE", "CO", "CO"],
        "chart_date": pd.to_datetime(["2026-06-18"] * 3),
        "position": [1, 2, 1],
        "artist": ["a", "b", "c"],
        "song_name": ["x", "y", "z"],
        "stream_count": [100, 200, 300],
        "label_group": ["Universal", "Sony", "Universal"],
        "label_name": ["UMG", "Sony Music", "UMG"],
    })
    detalle = chart_semanal.construir_detalle_tracks(df_semana)

    assert list(detalle["position"]) == [1, 2]  # 2 posiciones distintas, no 3 filas
    fila_pos1 = detalle.loc[detalle["position"] == 1].iloc[0]
    assert fila_pos1["CO"] == "z / c"  # posición 1 en Colombia
    assert fila_pos1["PE"] == "x / a"  # posición 1 en Perú
    fila_pos2 = detalle.loc[detalle["position"] == 2].iloc[0]
    assert fila_pos2["CO"] == "y / b"
    assert pd.isna(fila_pos2["PE"])  # Perú no tiene track en la posición 2 esta semana


def test_construir_detalle_tracks_vacio_no_falla(tmp_path):
    assert chart_semanal.construir_detalle_tracks(pd.DataFrame()).empty


def test_conteo_universal_coincide_con_datos_reales_de_colombia_semana_24(tmp_path):
    # Validación Paso 6: estos son los 10 tracks REALES del Top 10 de Colombia
    # en la semana del 2026-06-11 (BASE Informe Sportify charts Semana 24),
    # tal cual venían en la fuente cruda (position, label_group). El conteo
    # "Universal" para TOP 10 en el reporte oficial (Reporte_Chart_Top Semanal
    # Spotify Latam a Sem 24 de 2026.xlsm, fila de la semana 24) es 1 -- y la
    # validación completa (17 países x 5 bandas = 85 valores, hecha aparte
    # contra BASE Informe Sportify charts Semana 24 y el reporte oficial)
    # confirmó que este método coincide exactamente en los 85 casos. Este
    # test deja un caso real fijo como regresión rápida.
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    top10_reales_co = [
        (1, "Warner"), (2, "Warner"), (3, "INgrooves"), (4, "INgrooves"),
        (5, "Warner"), (6, "Warner"), (7, "Warner"), (8, "Sony"),
        (9, "Universal"), (10, "Warner"),
    ]
    df_semana = pd.DataFrame({
        "country_code": ["CO"] * 10,
        "label_group": [lbl for _, lbl in top10_reales_co],
        "position": [pos for pos, _ in top10_reales_co],
        "stream_count": [1_000_000] * 10,
        "chart_date": pd.to_datetime(["2026-06-11"] * 10),
    })
    history.append_semana_chart(df_semana)

    resumen = chart_semanal.construir_resumen_total()
    assert resumen.iloc[0]["CO_top10"] == 1  # valor oficial real verificado


def test_generar_reporte_escribe_las_dos_pestanas(tmp_path):
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO"],
        "chart_date": pd.to_datetime(["2026-06-18"]),
        "position": [1],
        "artist": ["a"],
        "song_name": ["x"],
        "stream_count": [1_000_000],
        "label_group": ["Universal"],
        "label_name": ["UMG"],
    })
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    assert salida.exists()
    wb = openpyxl.load_workbook(salida)
    assert wb.sheetnames == [config.CHART_SHEET_RESUMEN, config.CHART_SHEET_DETALLE]


def test_detalle_tracks_columna_posicion_y_encabezados_quedan_fijos(tmp_path):
    # Ajuste 4: columna de posición fija a la izquierda, fila de
    # semana/fecha + encabezado de país fijas arriba (freeze_panes) --
    # sin color todavía (el usuario no tiene definido el criterio de
    # colores para esta pestaña).
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO", "PE"],
        "chart_date": pd.to_datetime(["2026-06-18"] * 2),
        "position": [1, 1],
        "artist": ["a", "b"],
        "song_name": ["x", "y"],
        "stream_count": [1_000_000, 1_000_000],
        "label_group": ["Universal", "Universal"],
        "label_name": ["UMG", "UMG"],
    })
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    wb = openpyxl.load_workbook(salida)
    ws = wb[config.CHART_SHEET_DETALLE]

    assert ws.cell(row=1, column=1).value == "Week Ending - 18 jun, 2026"
    assert ws.cell(row=2, column=1).value == "Position"
    assert ws.cell(row=2, column=2).value == "CO"  # primer país -> orden de config.ORDEN_PAISES_CHART
    assert ws.cell(row=3, column=1).value == 1
    assert ws.cell(row=3, column=2).value == "x / a"
    # sin relleno de color en esta pestaña todavía
    assert ws.cell(row=3, column=2).fill.fgColor.rgb in (None, "00000000")
    assert ws.freeze_panes == "B3"  # columna A (posición) + filas 1-2 fijas


def test_resumen_total_replica_el_formato_de_la_plantilla_original(tmp_path):
    # Paso 7 (formato): freeze panes en las columnas/filas fijas, país
    # combinado en la fila 5 con el orden y nombre real de la plantilla,
    # bandas (10/30/50/100/200) en la fila 6, columna angosta de separación
    # entre cada país -- verificado 1:1 contra Reporte_Chart_Top Semanal
    # Spotify Latam a Sem 24 de 2026.xlsm (misma fila 5/6, freeze_panes E7,
    # 18 celdas combinadas).
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO", "PE"],
        "chart_date": pd.to_datetime(["2026-06-18"] * 2),
        "position": [1, 1],
        "artist": ["a", "b"],
        "song_name": ["x", "y"],
        "stream_count": [1_000_000, 1_000_000],
        "label_group": ["Universal", "Universal"],
        "label_name": ["UMG", "UMG"],
    })
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    wb = openpyxl.load_workbook(salida)
    ws = wb[config.CHART_SHEET_RESUMEN]

    assert ws.freeze_panes == "E7"
    assert ws.cell(row=5, column=3).value == "SEMANA \n/ TOP"
    assert ws.cell(row=5, column=5).value == "COLOMBIA"  # primer bloque de país (col E)
    assert ws.cell(row=5, column=11).value == "PERU"  # segundo bloque (col K) -- 1 col de separación (J)
    assert [ws.cell(row=6, column=c).value for c in range(5, 10)] == [10, 30, 50, 100, 200]
    assert ws.cell(row=6, column=10).value is None  # columna J: separadora, vacía
    assert ws.column_dimensions["J"].width < 3  # separadora, angosta
    # merges de la fila 5 nada más (la pestaña tiene más celdas combinadas
    # abajo, del listado de canciones -- ver test aparte).
    merges_fila_5 = [r for r in ws.merged_cells.ranges if r.min_row == 5]
    assert len(merges_fila_5) == 18  # 1 (SEMANA/TOP) + 17 países


def test_construir_listado_canciones_arma_una_fila_por_cancion_con_posicion_por_pais_y_totales(tmp_path):
    # "Coleccionando Heridas" queda en el Top 10 de Colombia (posición 5) y
    # en el Top 30 de Perú (posición 20) -- dos países, suma de posiciones
    # 25. "Golden" solo aparece en Perú, fuera del Top 200 (no debe listarse
    # con ninguna banda).
    df_semana = pd.DataFrame({
        "country_code": ["CO", "PE", "PE"],
        "chart_date": pd.to_datetime(["2026-06-18"] * 3),
        "position": [5, 20, 250],
        "artist": ["KAROL G", "KAROL G", "HUNTR/X"],
        "song_name": ["Coleccionando Heridas", "Coleccionando Heridas", "Golden"],
        "stream_count": [1_000_000] * 3,
        "label_group": ["Universal"] * 3,
        "label_name": ["UMG"] * 3,
        "region": ["Latin", "Latin", "Anglo"],
    })

    listado = chart_semanal.construir_listado_canciones(df_semana)

    assert len(listado) == 1  # "Golden" quedó fuera (posición 250, fuera del Top 200)
    fila = listado.iloc[0]
    assert fila["cancion"] == "Coleccionando Heridas / KAROL G"
    assert fila["region"] == "Latin"
    assert fila["paises_presente"] == 2
    assert fila["suma_posiciones"] == 25
    assert fila["CO_top10"] == 5  # posición 5 -> banda 10
    assert fila["PE_top30"] == 20  # posición 20 -> banda 30
    assert pd.isna(fila.get("PE_top10"))  # no le corresponde esa banda en Perú


def test_listado_canciones_vacio_no_falla(tmp_path):
    assert chart_semanal.construir_listado_canciones(pd.DataFrame()).empty


def test_construir_listado_canciones_se_recorta_a_las_mejores_200(tmp_path, monkeypatch):
    # Con una semana real puede haber 1000+ canciones distintas -- el
    # usuario pidió dejar solo las mejores 200 (mismo orden: más países y
    # mejor suma de posiciones primero). Se prueba con un límite más chico
    # (5) para no armar 250 filas de datos a mano.
    monkeypatch.setattr(config, "TOP_N_LISTADO_CANCIONES", 5)
    n_canciones = 8
    df_semana = pd.DataFrame({
        "country_code": ["CO"] * n_canciones,
        "chart_date": pd.to_datetime(["2026-06-18"] * n_canciones),
        "position": list(range(1, n_canciones + 1)),
        "artist": [f"artista{i}" for i in range(n_canciones)],
        "song_name": [f"cancion{i}" for i in range(n_canciones)],
        "stream_count": [1_000_000] * n_canciones,
        "label_group": ["Universal"] * n_canciones,
        "label_name": ["UMG"] * n_canciones,
        "region": ["Latin"] * n_canciones,
    })

    listado = chart_semanal.construir_listado_canciones(df_semana)

    assert len(listado) == 5
    # las 5 mejores son las de menor suma de posiciones (todas con 1 solo
    # país, así que desempata por suma_posiciones ascendente)
    assert list(listado["suma_posiciones"]) == [1, 2, 3, 4, 5]


def test_resumen_total_incluye_el_listado_de_canciones_debajo_de_la_serie_historica(tmp_path):
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO", "PE"],
        "chart_date": pd.to_datetime(["2026-06-18"] * 2),
        "position": [1, 40],
        "artist": ["a", "b"],
        "song_name": ["x", "y"],
        "stream_count": [1_000_000, 1_000_000],
        "label_group": ["Universal", "Universal"],
        "label_name": ["UMG", "UMG"],
        "region": ["Latin", "Anglo"],
    })
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    wb = openpyxl.load_workbook(salida)
    ws = wb[config.CHART_SHEET_RESUMEN]

    # Con una sola semana histórica, la serie ocupa la fila 7; el listado
    # empieza 2 filas en blanco después (filas 8-9), título en la fila 10,
    # encabezados en 11/12, primera canción en la 13.
    assert ws.cell(row=10, column=1).value == "Week Ending - 18 jun, 2026"
    assert ws.cell(row=11, column=1).value == "Artist/Título"
    assert ws.cell(row=11, column=3).value == "Región"
    assert ws.cell(row=11, column=5).value == "COLOMBIA"
    assert [ws.cell(row=12, column=c).value for c in range(5, 10)] == [10, 30, 50, 100, 200]
    # columnas finales sin nombre en la plantilla original -> las nombramos.
    # Columna 107 = después del bloque 17 (países) x 6 (5 bandas + 1
    # separadora) empezando en la columna 5.
    col_paises, col_suma = 107, 108
    assert ws.cell(row=11, column=col_paises).value == "N° Países"
    assert ws.cell(row=11, column=col_suma).value == "Suma Posiciones"

    assert ws.cell(row=13, column=1).value == "x / a"
    assert ws.cell(row=13, column=3).value == "Latin"
    assert ws.cell(row=13, column=5).value == 1  # CO, banda 10
    assert ws.cell(row=13, column=col_paises).value == 1
    assert ws.cell(row=13, column=col_suma).value == 1


def test_color_semaforo_participacion_universal():
    # Ejemplo confirmado con el usuario para banda=10 (objetivo = 3 canciones,
    # 30% de 10): 1-2 -> rojo, 3 -> amarillo, 4-10 -> verde. 0 se trata igual
    # que 1-2 (rojo, todavía más lejos del objetivo).
    assert chart_semanal._color_semaforo(10, 0) is chart_semanal._RELLENO_ROJO
    assert chart_semanal._color_semaforo(10, 1) is chart_semanal._RELLENO_ROJO
    assert chart_semanal._color_semaforo(10, 2) is chart_semanal._RELLENO_ROJO
    assert chart_semanal._color_semaforo(10, 3) is chart_semanal._RELLENO_AMARILLO
    assert chart_semanal._color_semaforo(10, 4) is chart_semanal._RELLENO_VERDE
    assert chart_semanal._color_semaforo(10, 10) is chart_semanal._RELLENO_VERDE
    # Mismo criterio (30%) aplicado a las demás bandas -> objetivo 9/15/30/60
    assert chart_semanal._color_semaforo(30, 9) is chart_semanal._RELLENO_AMARILLO
    assert chart_semanal._color_semaforo(50, 15) is chart_semanal._RELLENO_AMARILLO
    assert chart_semanal._color_semaforo(100, 30) is chart_semanal._RELLENO_AMARILLO
    assert chart_semanal._color_semaforo(200, 60) is chart_semanal._RELLENO_AMARILLO
    # Sin dato -> sin color
    assert chart_semanal._color_semaforo(10, None) is None


def test_resumen_total_colorea_conteo_universal_segun_participacion(tmp_path):
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    # Top 10 de Colombia: 2 Universal -> rojo (objetivo 3). Top 10 de Perú:
    # 3 Universal -> amarillo. Top 10 de Ecuador: 5 Universal -> verde.
    filas = []
    for pais, universales in [("CO", 2), ("PE", 3), ("EC", 5)]:
        for i in range(10):
            label = "Universal" if i < universales else "Sony"
            filas.append({"country_code": pais, "position": i + 1, "label_group": label})
    df_semana = pd.DataFrame({
        "country_code": [f["country_code"] for f in filas],
        "chart_date": pd.to_datetime(["2026-06-18"] * len(filas)),
        "position": [f["position"] for f in filas],
        "artist": ["a"] * len(filas),
        "song_name": ["x"] * len(filas),
        "stream_count": [1_000_000] * len(filas),
        "label_group": [f["label_group"] for f in filas],
        "label_name": ["UMG"] * len(filas),
    })
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    wb = openpyxl.load_workbook(salida)
    ws = wb[config.CHART_SHEET_RESUMEN]

    celda_co = ws.cell(row=7, column=5)  # CO_top10
    celda_pe = ws.cell(row=7, column=11)  # PE_top10
    celda_ec = ws.cell(row=7, column=17)  # EC_top10

    assert celda_co.value == 2 and celda_co.fill.fgColor.rgb.endswith(config.COLOR_SEMAFORO_ROJO)
    assert celda_pe.value == 3 and celda_pe.fill.fgColor.rgb.endswith(config.COLOR_SEMAFORO_AMARILLO)
    assert celda_ec.value == 5 and celda_ec.fill.fgColor.rgb.endswith(config.COLOR_SEMAFORO_VERDE)


# --- Fecha de Lanzamiento (vía Spotify, ver spotify_release_dates.py) ---

class _ClienteSpotifyFalso:
    """Doble de prueba de spotify_release_dates.SpotifyReleaseDateClient --
    no llama a la red, para poder probar la columna "Fecha de Lanzamiento"
    de forma determinista."""

    def __init__(self, id_por_isrc: dict, fecha_por_id: dict):
        self.id_por_isrc = id_por_isrc
        self.fecha_por_id = fecha_por_id

    def buscar_track_id_por_isrc(self, isrc):
        return self.id_por_isrc.get(isrc)

    def fechas_de_lanzamiento(self, track_ids):
        return {tid: self.fecha_por_id.get(tid) for tid in track_ids}


def test_construir_listado_canciones_isrc_por_defecto_none_si_falta_columna():
    # "ISRC" viene de la fuente BQ real (config.SOURCE_COLUMNS), pero no
    # todo caller de prueba la incluye -- que falte no debe tumbar el
    # reporte, solo queda sin poder resolver la fecha de lanzamiento.
    df_semana = pd.DataFrame({
        "country_code": ["CO"], "chart_date": pd.to_datetime(["2026-06-18"]),
        "position": [1], "artist": ["a"], "song_name": ["x"],
        "stream_count": [1_000_000], "label_group": ["Universal"], "label_name": ["UMG"],
        "region": ["Latin"],
    })
    listado = chart_semanal.construir_listado_canciones(df_semana)
    assert pd.isna(listado.iloc[0]["isrc"])


def test_agregar_fecha_lanzamiento_resuelve_desde_isrc_con_cliente_de_prueba():
    listado = pd.DataFrame({"cancion": ["a / x", "b / y"], "isrc": ["ISRC1", "ISRC2"]})
    cliente = _ClienteSpotifyFalso(
        id_por_isrc={"ISRC1": "track1", "ISRC2": "track2"},
        fecha_por_id={"track1": "2019-01-01", "track2": "2021-05-05"},
    )
    resultado = chart_semanal.agregar_fecha_lanzamiento(listado, cliente=cliente)
    assert list(resultado["fecha_lanzamiento"]) == ["2019-01-01", "2021-05-05"]


def test_agregar_fecha_lanzamiento_sin_credenciales_no_rompe_el_reporte(tmp_path, monkeypatch):
    # Si no hay SPOTIFY_CLIENT_ID/SECRET configurados (ej. la primera vez
    # que se corre esto, antes de armar el .env) o la API falla por
    # cualquier motivo, la columna queda en blanco para esta corrida en vez
    # de tumbar todo el reporte -- se vuelve a intentar la próxima vez.
    monkeypatch.delenv("SPOTIFY_CLIENT_ID", raising=False)
    monkeypatch.delenv("SPOTIFY_CLIENT_SECRET", raising=False)
    listado = pd.DataFrame({"cancion": ["a / x"], "isrc": ["ISRC1"]})
    resultado = chart_semanal.agregar_fecha_lanzamiento(listado, cliente=None)
    assert resultado["fecha_lanzamiento"].iloc[0] is None


def test_agregar_fecha_lanzamiento_listado_vacio_no_rompe():
    resultado = chart_semanal.agregar_fecha_lanzamiento(pd.DataFrame(columns=["cancion", "isrc"]))
    assert "fecha_lanzamiento" in resultado.columns
    assert resultado.empty


def test_listado_canciones_incluye_fecha_de_lanzamiento_con_cliente_de_prueba(tmp_path):
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO"],
        "chart_date": pd.to_datetime(["2026-06-18"]),
        "position": [1],
        "artist": ["a"],
        "song_name": ["x"],
        "stream_count": [1_000_000],
        "label_group": ["Universal"],
        "label_name": ["UMG"],
        "region": ["Latin"],
        "ISRC": ["ISRC_X"],
    })
    cliente = _ClienteSpotifyFalso(
        id_por_isrc={"ISRC_X": "trackX"}, fecha_por_id={"trackX": "2020-03-15"},
    )
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida, cliente_spotify=cliente)

    wb = openpyxl.load_workbook(salida)
    ws = wb[config.CHART_SHEET_RESUMEN]

    # La fecha va en la columna B (_COL_MES), entre "Artist/Título" (A) y
    # "Región" (C) -- así lo pidió el usuario mostrando la plantilla real.
    # Importante: no debe correr los bloques de país (siguen empezando en la
    # columna 5, alineados con la serie histórica de arriba).
    assert ws.cell(row=11, column=2).value == "Fecha Lzto"
    assert ws.cell(row=13, column=2).value == "2020-03-15"
    assert ws.cell(row=11, column=1).value == "Artist/Título"
    assert ws.cell(row=11, column=3).value == "Región"
    assert ws.cell(row=13, column=3).value == "Latin"


def test_generar_reporte_sin_credenciales_de_spotify_no_rompe(tmp_path, monkeypatch):
    # Escenario real: el usuario corre el reporte antes de configurar el
    # .env de Spotify -- el reporte se tiene que seguir generando igual,
    # solo sin la columna de fecha llena.
    monkeypatch.delenv("SPOTIFY_CLIENT_ID", raising=False)
    monkeypatch.delenv("SPOTIFY_CLIENT_SECRET", raising=False)

    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO"], "chart_date": pd.to_datetime(["2026-06-18"]),
        "position": [1], "artist": ["a"], "song_name": ["x"],
        "stream_count": [1_000_000], "label_group": ["Universal"], "label_name": ["UMG"],
        "region": ["Latin"], "ISRC": ["ISRC_X"],
    })
    salida = tmp_path / "reporte.xlsx"
    # No debe lanzar excepción.
    chart_semanal.generar_reporte(df_semana, salida)

    wb = openpyxl.load_workbook(salida)
    ws = wb[config.CHART_SHEET_RESUMEN]
    assert ws.cell(row=11, column=2).value == "Fecha Lzto"
    assert ws.cell(row=13, column=2).value is None


# --- semáforo de la posición en el listado de canciones (reunión 14/09/2026) ---

def test_pintar_posicion_usa_el_color_de_cada_banda():
    # Verde el Top 10, amarillo el 30 y el 50, rojo el 100 y el 200.
    class _Celda:
        fill = None
        font = None

    esperado = {
        10: config.COLOR_SEMAFORO_VERDE,
        30: config.COLOR_SEMAFORO_AMARILLO,
        50: config.COLOR_SEMAFORO_AMARILLO,
        100: config.COLOR_SEMAFORO_ROJO,
        200: config.COLOR_SEMAFORO_ROJO,
    }
    for banda in config.BANDAS_CHART:
        celda = _Celda()
        chart_semanal._pintar_posicion(celda, banda)
        assert str(celda.fill.start_color.rgb)[-6:] == esperado[banda], banda


def test_listado_de_canciones_pinta_la_posicion_segun_su_banda(tmp_path):
    # Tres canciones que caen en tres bandas distintas del mismo país, para
    # ver los tres colores en la hoja generada.
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO", "CO", "CO"],
        "chart_date": pd.to_datetime(["2026-06-18"] * 3),
        "position": [3, 45, 150],          # banda 10, banda 50, banda 200
        "artist": ["a", "b", "c"],
        "song_name": ["x", "y", "z"],
        "stream_count": [3_000_000, 2_000_000, 1_000_000],
        "label_group": ["Universal"] * 3,
        "label_name": ["UMG"] * 3,
        "region": ["Latin"] * 3,
    })
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    ws = openpyxl.load_workbook(salida)[config.CHART_SHEET_RESUMEN]

    def color(celda):
        if celda.fill is None or celda.fill.fill_type is None:
            return None
        return str(getattr(celda.fill.start_color, "rgb", ""))[-6:]

    # El bloque de Colombia empieza en la columna 5; una columna por banda.
    col_top10, col_top50, col_top200 = 5, 7, 9
    # Las canciones salen ordenadas por posición (todas en un solo país), así
    # que la primera fila del listado (13) es la posición 3.
    assert ws.cell(row=13, column=col_top10).value == 3
    assert color(ws.cell(row=13, column=col_top10)) == config.COLOR_SEMAFORO_VERDE
    assert ws.cell(row=14, column=col_top50).value == 45
    assert color(ws.cell(row=14, column=col_top50)) == config.COLOR_SEMAFORO_AMARILLO
    assert ws.cell(row=15, column=col_top200).value == 150
    assert color(ws.cell(row=15, column=col_top200)) == config.COLOR_SEMAFORO_ROJO
    # Una celda vacía del mismo bloque no se pinta.
    assert color(ws.cell(row=13, column=col_top50)) is None


# --- cuadrícula del Chart Semanal (reunión 14/09/2026) ---

def _tiene_todos_los_bordes(celda) -> bool:
    lados = (celda.border.left, celda.border.right, celda.border.top, celda.border.bottom)
    return all(lado is not None and lado.style for lado in lados)


def test_resumen_total_y_detalle_tracks_salen_en_cuadricula(tmp_path):
    chart_csv = tmp_path / "seed_chart.csv"
    pd.DataFrame([
        {"anio": 2026, "semana": 1, "mes": "ENERO", "country_code": "CO",
         "banda": 10, "conteo_universal": 1},
    ]).to_csv(chart_csv, index=False)
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = pd.DataFrame({
        "country_code": ["CO"],
        "chart_date": pd.to_datetime(["2026-06-18"]),
        "position": [1], "artist": ["a"], "song_name": ["x"],
        "stream_count": [1_000_000], "label_group": ["Universal"],
        "label_name": ["UMG"], "region": ["Latin"],
    })
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    wb = openpyxl.load_workbook(salida)
    ws = wb[config.CHART_SHEET_RESUMEN]
    # Serie histórica. Ojo con las celdas combinadas: en la fila 5 las tres
    # columnas de la izquierda y el nombre del país llevan el borde en su
    # celda inicial, y el resto del rango sale sin borde al releer (así
    # guarda openpyxl los rangos combinados; en Excel se ve el recuadro).
    for col in (1, 2, 3, 5):
        assert _tiene_todos_los_bordes(ws.cell(row=5, column=col)), col
    for col in (5, 9):                       # fila de bandas (10..200) de CO
        assert _tiene_todos_los_bordes(ws.cell(row=6, column=col)), col
    for fila in (7, 8):                      # semana sembrada y semana nueva
        for col in (1, 2, 3, 5, 9):
            assert _tiene_todos_los_bordes(ws.cell(row=fila, column=col)), (fila, col)
    # La columna separadora entre bloques de país queda SIN borde.
    assert not _tiene_todos_los_bordes(ws.cell(row=7, column=4))
    assert not _tiene_todos_los_bordes(ws.cell(row=7, column=10))

    # Listado de canciones: encabezados y la fila de la canción.
    fila_titulo = next(r for r in range(1, ws.max_row + 1)
                       if str(ws.cell(row=r, column=1).value or "").startswith("Week Ending"))
    for col in (1, 2, 3, 5):                 # encabezado (combinado hacia abajo)
        assert _tiene_todos_los_bordes(ws.cell(row=fila_titulo + 1, column=col)), col
    assert _tiene_todos_los_bordes(ws.cell(row=fila_titulo + 2, column=5))  # bandas
    for col in (1, 2, 3, 5):                 # primera canción
        assert _tiene_todos_los_bordes(ws.cell(row=fila_titulo + 3, column=col)), col

    # Detalle Tracks: posición + países, sin separadoras.
    det = wb[config.CHART_SHEET_DETALLE]
    for fila in (2, 3):
        for col in (1, 2):
            assert _tiene_todos_los_bordes(det.cell(row=fila, column=col)), (fila, col)


# --- detalle de productos: solo Universal, una línea por track (16/09/2026) ---

def _semana_con_varios_sellos(chart_date="2026-09-10"):
    """CO: 2 tracks Universal en el TOP 10 y 3 de otros sellos."""
    filas = []
    for pos, sello, nombre in [
        (1, "Sony", "Ajena A"), (2, "Universal", "Uni A"), (3, "Warner", "Ajena B"),
        (4, "Universal", "Uni B"), (5, "Indies", "Ajena C"),
    ]:
        filas.append({
            "country_code": "CO", "chart_date": pd.Timestamp(chart_date), "position": pos,
            "artist": "Artista", "song_name": nombre, "stream_count": 1_000_000,
            "label_group": sello, "label_name": sello, "region": "Latin", "ISRC": f"I{pos}",
        })
    return pd.DataFrame(filas)


def test_el_listado_solo_trae_productos_universal(tmp_path):
    # Comentario del revisor: "únicamente deben incluirse los productos que
    # estén marcados como Universal". En el TOP 10 de CO hay 5 tracks pero
    # solo 2 son de Universal.
    listado = chart_semanal.construir_listado_canciones(_semana_con_varios_sellos())

    assert len(listado) == 2
    assert sorted(listado["cancion"]) == ["Uni A / Artista", "Uni B / Artista"]


def test_el_listado_cuenta_una_sola_vez_el_track_partido_entre_sellos(tmp_path):
    # El track llega en dos filas (market share compartido): una sola línea,
    # y "Suma Posiciones" no se duplica.
    filas = []
    for streams in (300_000.0, 700_000.0):
        filas.append({
            "country_code": "CO", "chart_date": pd.Timestamp("2026-09-10"), "position": 7,
            "artist": "Artista", "song_name": "Partida", "stream_count": streams,
            "label_group": "Universal", "label_name": "UMG", "region": "Latin", "ISRC": "I7",
        })
    listado = chart_semanal.construir_listado_canciones(pd.DataFrame(filas))

    assert len(listado) == 1
    assert listado["paises_presente"].iloc[0] == 1
    assert listado["suma_posiciones"].iloc[0] == 7      # no 14
    assert listado["CO_top10"].iloc[0] == 7


def test_el_listado_deja_fuera_el_track_empatado_entre_dos_sellos(tmp_path):
    filas = []
    for sello in ("Universal", "Sony"):
        filas.append({
            "country_code": "CO", "chart_date": pd.Timestamp("2026-09-10"), "position": 8,
            "artist": "Artista", "song_name": "Empatada", "stream_count": 500_000.0,
            "label_group": sello, "label_name": sello, "region": "Latin", "ISRC": "I8",
        })
    listado = chart_semanal.construir_listado_canciones(pd.DataFrame(filas))
    assert listado.empty


def test_el_detalle_cuadra_con_la_serie_historica(tmp_path):
    # Es la comprobación que hizo el revisor: cuántos tracks muestra el
    # detalle en cada banda tiene que ser el número de la serie de arriba.
    chart_csv = _csv_vacio(tmp_path, "seed_chart.csv",
                           ["anio", "semana", "mes", "country_code", "banda", "conteo_universal"])
    ms_csv = _csv_vacio(tmp_path, "seed_ms.csv",
                        ["anio", "semana", "country_code", "label_group", "streams_top200", "chart_date"])
    history.seed_historico(chart_csv, ms_csv)

    df_semana = _semana_con_varios_sellos()
    salida = tmp_path / "reporte.xlsx"
    chart_semanal.generar_reporte(df_semana, salida)

    ws = openpyxl.load_workbook(salida)[config.CHART_SHEET_RESUMEN]
    serie_top10 = ws.cell(row=7, column=5).value          # CO, banda 10
    fila_tit = next(r for r in range(1, ws.max_row + 1)
                    if str(ws.cell(row=r, column=1).value or "").startswith("Week Ending"))
    en_detalle = sum(1 for r in range(fila_tit + 3, ws.max_row + 1)
                     if isinstance(ws.cell(row=r, column=5).value, int))
    assert serie_top10 == 2
    assert en_detalle == serie_top10
